#include<stdio.h>
int main(){
	int a,i,sum=0,avg;
	for(i=0;i<10;i++)
	{
		printf("ENTER THE ELEMENT IN ARRAY :- ");
		scanf("%d",&a);
		sum=sum+a;
	}
	avg=sum/10;
	printf("AVERAGE OF ALL NUMBER IS :- %d",avg);
}