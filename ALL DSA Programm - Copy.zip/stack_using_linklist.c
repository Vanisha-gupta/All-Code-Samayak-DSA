#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *next;
}*top,*q,*t;

void push(int);
void pop();
void display();

int main(){
	int choice,i,val;
	top=NULL;
	do
	{
		printf("press 1 for insertion \n");
		printf("press 2 for pop \n");
		printf("press 3 for display \n");
        scanf("%d",&choice);
		 switch(choice)
		 {
		 	case 1:printf("enter value in link list :- ");
		 	scanf("%d",&val);
		 	push(val);
		 	break;
		 	
		 	case 2:pop();
		 	break;
		 	
		 	case 3:display();
		 	break;
		 	
		 	default:printf("wrong choice\n");
		 }
	}while(choice!=11);
	return 0;
}

void push(int num)
{
	q=top;
	t=(struct node*)malloc(sizeof(struct node));
	t->data=num;
	t->next=top;
	top=t;
}

void pop()
{
	if(top==NULL)
	printf("underflow");
	else
	{
		printf("pop item is :- %d\n",top->data);
		top=top->next;
	}
}

void display()
{
	if(top==NULL)
			printf("underflow \n");
		else
	for(q=top;q!= NULL;q=q->next)
		printf(" %d\n",q->data);
}
		