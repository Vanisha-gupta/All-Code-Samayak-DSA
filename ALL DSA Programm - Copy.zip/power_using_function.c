#include<stdio.h>
int pow(int c,int d)
{
	int power;
	if(d==0)
	return 1;
	if(d>0)
	{
		power=c*pow(c,d-1);
	}
	else if(d<0)
	{
		power=c*pow(c,d+1);
	}
}
int main()
{
	int a,b,i;
	printf("enter a :- ");
	scanf("%d",&a);
	printf("enter b :- ");
	scanf("%d",&b);
	printf("%d",pow(a,b));
	return 0;
}