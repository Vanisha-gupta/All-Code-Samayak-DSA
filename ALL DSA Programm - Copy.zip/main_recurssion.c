#include<stdio.h>
int main()
{
	printf("hii \n");
	main();
	return 0;
}

// this will not work

/*
main()
{
	printf("hello\n");
}*/