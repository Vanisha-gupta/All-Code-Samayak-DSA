#include<stdio.h>
int main()
{
	int n,m,i,j,count=0; // user input not working
	int a[10][10];
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			printf("enter element :- \n");
			scanf("%d",&a[i][j]);
			if(a[i][j]==0)
			{
				count++;
			}
		}
	}
	
	if(count>=(3*3)/2)
	{
		printf("sparse matrix ");
	}
	else
	{
		printf("not a sparse matrix ");
	}
	return 0;
	
}