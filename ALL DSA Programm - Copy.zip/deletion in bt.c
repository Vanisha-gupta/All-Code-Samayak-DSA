#include<stdio.h>  
#include<stdlib.h>  
#include<stdbool.h> 
struct node{  
    int data;  
    struct node *left;  
    struct node *right;  
};   

struct node *root = NULL;  

struct queue
{
	struct node *data;
	struct queue *next;
}*start,*front,*rear; 

void postorder(struct node *root);
void preorder(struct node *root);
void inorder(struct node *root);
void insert(struct node *);
void search(struct node *root,int ele,struct node *prev);
struct node * del();
struct node * AfterDelete(struct node *TobeDelete);

/*void dele(struct node *root,int data1)
{
	
	struct node *prev;
	prev=root;
	if(root->left->data == data1)
	{
		
		if(root->left!=NULL &&)
	}
	if(prev->left->data->data == data1){
		if(root->left!=NULL && root->right!=NULL)
		{
			pev->left=NULL;
		}
	}
	
	if(prev->right->data->data == data1){
		if(root->left!=NULL && root->right!=NULL)
		{
			pev->right=NULL;
		}
	}

}*/

void display()
{
	if(start==NULL)
			printf("empty list\n");
		else
	for(front=start;front!= NULL;front=front->next)
		printf(" %d\n",front->data->data);
} 

struct node* createNode(int data)
{  
struct node *newNode = (struct node *)malloc(sizeof(struct node));  
    newNode->data = data;  
    newNode->left = NULL;  
    newNode->right = NULL;
    return newNode;  
}  

void insert(struct node *data)
{ 
	if(start==NULL)
	{
		start=(struct queue*)malloc(sizeof(struct queue));
		start->data=data;
		start->next=NULL;
	}
	else
	{
			front=start;
			while(front->next != NULL)
			{
				front=front->next;
			}
		
		rear=(struct queue*)malloc(sizeof(struct queue));
		rear->data=data;
		rear->next=NULL;
		front->next=rear;
	}
}

struct node* del()
{
	if(start==NULL)
	{
		printf("underflow queue\n");
	}
	else
	{
		struct queue* x=start;
		start=start->next;
		return x->data;
	}
}  

void insertNode(int data,struct node *tempRoot,struct node *Insertableroot) {
	struct node *newNode;
if(tempRoot==NULL && Insertableroot ==NULL) 
   {
    newNode = createNode(data);
   }
   else
   {
   	newNode=Insertableroot;
   }
    if(root == NULL&&tempRoot==NULL && Insertableroot ==NULL){  
        root = newNode;  
        return;  
    }  
    else {  
		start=NULL;
		front=NULL;
		rear=NULL; 
		if(tempRoot==NULL && Insertableroot ==NULL) 
          insert(root); 
        else
         insert(tempRoot); 
       
        while(true) {  
            struct node *node = del();  // ???.... *node
            if(node->left != NULL && node->right != NULL) {  
                insert(node->left);  
                insert(node->right);  
            }  
            else {  
                if(node->left == NULL) {  
                    node->left = newNode;  
                    //insert(node->left);   
                }  
                else {  
                    node->right = newNode;  
                    //insert(node->right);  
                }  
                break;  
            }  
        }  
    }  
}  
   
int main(){  
int choice,val;
struct node *prev;
	do
		{
		printf("press 1 for insertion \n");
		printf("press 2 for display \n");
		printf("press 3 for delete \n");
		printf("press 4 for Exit \n");
		
		scanf("%d",&choice);
		 switch(choice)
		 {
		 	case 1:printf("enter value in binary tree :- ");
		 	scanf("%d",&val);
		 	insertNode(val,NULL,NULL);
		 	break;
		 	
		 	case 2:inorder(root);
		 	break;
		 	
		 	case 3:
			 printf("enter value :- ");
		 	scanf("%d",&val);
		 	
			 search(root,val,root); //  ???
			 /*printf("%d \n",prev->data);
			if(prev->left->data==val)
			 printf("Data found in left");
			 else if(prev->right->data==val)
			 /*printf("Data found in right");*/
		 	break;
		 	
		 	default:printf("wrong choice\n");
		 }
	}while(choice<4);
	return 0;
}

void preorder(struct node *root)
{
	if(root != NULL)
	{
		printf("%d \n",root->data);
		preorder(root->left);
		preorder(root->right);
	}
}

void inorder(struct node *root)
{
	if(root != NULL)
	{
		inorder(root->left);
		printf("%d \n",root->data);
		inorder(root->right);
	}
}

void postorder(struct node *root)
{
	if(root != NULL)
	{ 
		postorder(root->left);
		postorder(root->right);
		printf("%d \n",root->data);
	}
}
struct node *found=NULL;

void search(struct node *root,int ele,struct node *prev)
{
	if(root!=NULL && root->data != ele) 
	{ 
	    //prev=root;
	    //printf("%d \n",prev->data);
		search(root->left,ele,root);
		search(root->right,ele,root);
	}
	else if(root!=NULL && root->data == ele)
	{
		found=prev;
		printf("\n\n %d \n\n",prev->data);
		if(prev==root)
		{
			root=AfterDelete(root);
		}
	   else if(found->left!=NULL && found->left->data==ele)
		{
		found->left=AfterDelete(found->left);
		inorder(found);	
		}
		else
		{
			found->right=AfterDelete(found->right);
			inorder(found);
		}
		//printf("%d \n",found->data);
		//return prev;
	}
	//return found;
}

struct node * AfterDelete(struct node *TobeDelete)
{
	if(TobeDelete->left==NULL && TobeDelete->right==NULL)
	{
		return NULL;
	}
	else if(TobeDelete->left==NULL)
	{
		return TobeDelete->right;
	}
	else if(TobeDelete->right==NULL)
	{
		return TobeDelete->left;
	}
	else
	{
		insertNode(0,TobeDelete->left,TobeDelete->right);
		return TobeDelete->left;
	}
	
	/*if(root!=NULL && root->data != ele) 
	{ 
	    //prev=root;
	    //printf("%d \n",prev->data);
		search(root->left,ele,root);
		search(root->right,ele,root);
	}
	else if(root!=NULL && root->data == ele)
	{
		found=prev;
		printf("%d \n",found->data);
		return prev;
	}
	return found;*/
	return NULL;
}