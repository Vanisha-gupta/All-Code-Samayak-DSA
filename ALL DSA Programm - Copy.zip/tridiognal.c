#include<stdio.h>
int main()
{
	int n,m,i,j,count=0;
	printf("enter the value of row :- ");
	scanf("%d",&n);
	int a[10][10];
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("enter element :- \n");
			scanf("%d",&a[i][j]);
			if(a[i][j]==0)
			{
				count++;
			}
		}
	}
	
	if(count>=(n*n)/2)
	{
		printf("sparse matrix ");
		
		if((i==j || i==j+1 || j==i+1) && a[i][j]!= 0) // here 
		{
			printf(" as well as tridiagnol\n");
		}
		else
		{
			printf(" but not a tridiagnol matrix");
		}
		
	}
	else
	{
		printf("not a sparse matrix \n");
	}
	return 0;
}