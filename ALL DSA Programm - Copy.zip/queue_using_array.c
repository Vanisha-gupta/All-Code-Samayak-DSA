#include<stdio.h>
#include<stdlib.h>
#define max 5
int qu[max];
int front=-1,rear=-1;

void insert(int);
void del();
void display();

int main()
{
	int choice,val;
	
		do
		{
		printf("press 1 for insertion \n");
		printf("press 2 for display \n");
		printf("press 3 for delete \n");
		printf("press 4 for Exit \n");
		
		scanf("%d",&choice);
		 switch(choice)
		 {
		 	case 1:printf("enter value in link list :- ");
		 	scanf("%d",&val);
		 	insert(val);
		 	break;
		 	
		 	case 2:display();
		 	break;
		 	
		 	case 3:del();
		 	break;
		 	
		 	default:printf("wrong choice\n");
		 }
	}while(choice<4);
	return 0;
}

void insert( int n)
{
	if(front==-1)
	{
		++front;
		++rear;
		qu[rear]=n;
	}
	else if(rear>=(max-1))
	{
		printf(" element can not be insert\n");
	}
	else
	{
		++rear;
		qu[rear]=n;	
	}
}

void del()
{
	int i,j;
	if(rear==-1)
	{
	   printf("underflow \n");
	}
	else
	{
		for(i=0;i<=rear;i++)
		{
			qu[i]=qu[i+1];
		}
		--rear;
	}
}

void display()
{
	int i;
	for(i=front;i<=rear;i++)
		{
			printf("element is :- %d\n",qu[i]);
		}
}