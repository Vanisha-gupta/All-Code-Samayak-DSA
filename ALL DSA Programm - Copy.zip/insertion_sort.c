#include<stdio.h>
int main()
{
	int i,j,a[]={1,2,6,3,4};
	for(i=0;i<5;i++)
	{
		for(j=i+1;j>0 && a[j]<a[j-1];j--)
		{
			int t;
			t=a[j];
			a[j]=a[j-1];
			a[j-1]=t;
		}
	}
	// for printing 
	for(i=0;i<5;i++)
	{          
		printf("array sorted elemented :- %d\n",a[i]);
	}
	return 0;
}