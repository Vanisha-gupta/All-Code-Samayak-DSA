//#include<stdio.h>
int sum();
int main()
{
	printf("%d",sum());
}
int sum()
{
	int a=10,b=20;
	int c=a+b;
	printf("sum is :- ");
	printf("%d",52);
}