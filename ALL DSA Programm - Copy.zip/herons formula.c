#include<stdio.h>
#include<math.h>
int main()
{
	float a,b,c,area,s,samp;
	printf("Enter the value of first side :- \n");
	printf("Enter the value of for 2nd side :- \n");
	printf("Enter the value of 3rd side :- \n");
	scanf("%f%f%f",&a,&b,&c);
	if(a+b>c || a+c>b ||c+b>a)
	{
		//code 
		s=(a+b+c)/2;
		samp=s*(s-a)*(s-b)*(s-c);
		area=sqrt(samp);
		printf("area of triangle is %f",area);
	}
	else
	{
		printf("sides doesn`t made triangle");
	}
}