#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *next;
}*start,*q,*t;

void create (int num);
void display();
void count();

int main(){
	int choice,i,val;
	start=NULL;
	do
	{
		printf("press 1 for insertion \n");
		printf("press 2 for display \n");
		printf("press 3 for counting \n");
		scanf("%d",&choice);
		 //traversing ?
		 switch(choice)
		 {
		 	case 1:printf("enter value in link list :- ");
		 	scanf("%d",&val);
		 	create(val);
		 	break;
		 	
		 	case 2:display();
		 	break;
		 	
		 	case 3:count();
		 	break;
		 	
		 	default:break;
		 }
	}while(1);
	return 0;
}

void create (int num)
{
	if(start==NULL)
	{ 
		start=(struct node*)malloc(sizeof(struct node));
		start ->data=num;
		start ->next=NULL;
	}
	
	else
	{
			q=start;
			while(q->next != NULL)
			{
				q=q ->next;
			}
			t=(struct node*)malloc(sizeof(struct node));
			t->data =num;
			t->next=NULL;
	}
}
void display()
{
	for(q=start;q!= NULL;q=q->next)
	{   
		if(start==NULL)
		{
			printf("empty list ");
		}
		printf("%d\n",q->data);
	}
}