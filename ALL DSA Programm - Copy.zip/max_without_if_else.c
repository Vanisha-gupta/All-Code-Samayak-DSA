#include<stdio.h>
int main()
{
	int a=10,b=20;
	float c;
	c=(int)b;
	printf("%f",c);
	
	a= a * (bool)a/b + (b)*(bool)b/a;
	printf("the max value is :- %d",a);
	return 0;
}