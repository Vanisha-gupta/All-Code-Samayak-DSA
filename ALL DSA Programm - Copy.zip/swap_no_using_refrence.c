#include<stdio.h>
void swap(int *x,int *y)
{
	int t;
	t=*x;
	*x=*y;
	*y=t;
	printf("value of a is :- %d\n",*x);
	printf("value of a is :- %d\n",*y);
}
int main()
{
	int a=4,b=6;
	swap(&a,&b);
	return 0;
}