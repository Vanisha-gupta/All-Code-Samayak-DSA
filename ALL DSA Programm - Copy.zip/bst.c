#include<stdio.h>  
#include<stdlib.h>  
#include<stdbool.h> 
struct node{  
    int data;  
    struct node *left;  
    struct node *right;  
};   
struct node *root = NULL;  
struct queue
{
	struct node *data;
	struct queue *next;
}*start,*front,*rear; 

void postorder(struct node *root);
void preorder(struct node *root);
void inorder(struct node *root);
void insert(struct node *);
struct node * del();

void display()
{
	if(start==NULL)
			printf("empty list\n");
		else
	for(front=start;front!= NULL;front=front->next)
		printf(" %d\n",front->data->data);
} 

struct node* createNode(int data)
{  
struct node *newNode = (struct node *)malloc(sizeof(struct node));  
    newNode->data = data;  
    newNode->left = NULL;  
    newNode->right = NULL;
    return newNode;  
}  

void insert(struct node *data) // data pointer kun liya 
{ 
	if(start==NULL)
	{
		start=(struct queue*)malloc(sizeof(struct queue));
		start->data=data;
		start->next=NULL;
	}
	else
	{
			front=start;
			while(front->next != NULL)
			{
				front=front->next;
			}
		
		rear=(struct queue*)malloc(sizeof(struct queue));
		rear->data=data;
		rear->next=NULL;
		front->next=rear;
	}
}

struct node* del()
{
	if(start==NULL)
	{
		printf("underflow queue\n");
	}
	else
	{
		struct queue* x=start;
		start=start->next;
		return x->data;
	}
}  
void insertNode(int data) {    
    struct node *newNode = createNode(data);  
    if(root == NULL){  
        root = newNode;  
        return;  
    }  
    else {  
		start=NULL;
		front=NULL;
		rear=NULL; 
       insert(root); 
       
        while(true) {  
            struct node *node = del();  // ???.... *node
            if(node->left != NULL && node->right != NULL) {  
               // insert(node->left);  
               // insert(node->right);  
                if(node->data> newNode->data) {  
                   //1
				   // node->left = newNode;  
                    insert(node->left);   
                }  
                else if (node->data < newNode->data) 
				{  
                   // node->right =newNode;  
                    insert(node->right);  
                }
            }  
            else {  
                if(node->data > newNode->data) {  
                    node->left = newNode;  
                    //insert(node->left);   
                }  
                else 
				{  
                    node->right =newNode;  
                    //insert(node->right);  
                }  
                break;  
            }  
        }  
    }  
}  
   
int main(){  
int choice,val;
	do
		{
		printf("press 1 for insertion \n");
		printf("press 2 for display \n");
		printf("press 3 for delete \n");
		printf("press 4 for Exit \n");
		
		scanf("%d",&choice);
		 switch(choice)
		 {
		 	case 1:printf("enter value in binary tree :- ");
		 	scanf("%d",&val);
		 	insertNode(val);
		 	break;
		 	
		 	case 2:preorder(root);
		 	printf("inorder :- \n\n");
		 	inorder(root);
		 	break;
		 	case 3:del();
		 	break;
		 	default:printf("wrong choice\n");
		 }
	}while(choice<4);
	return 0;
}

void preorder(struct node *root)
{
	if(root != NULL)
	{
		printf("  %d \n",root->data);
		preorder(root->left);
		preorder(root->right);
	}
}

void inorder(struct node *root)
{
	if(root != NULL)
	{
		inorder(root->left);
		printf("  %d \n",root->data);
		inorder(root->right);
	}
}
void postorder(struct node *root)
{
	if(root != NULL)
	{
		postorder(root->left);
		postorder(root->right);
		printf("  %d \n",root->data);
	}
}