#include<stdio.h>
#include<math.h>
int main()
{
int a,i,sum=0;
printf("enter value till power count :- ");
scanf("%d",&a);
for(i=1;i<=a;i++)
sum+=pow(i,4);
//b=pow(b);
printf("%d",sum);
return 0;
}
