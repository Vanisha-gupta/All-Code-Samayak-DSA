#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *left;
	struct node *right;
}*start,*q,*t;
int count;
struct node *insert(node*root,int num);
//void display();

int main()
{
	start=NULL;
	int choice,val,position;
	do{
		printf("press 1 for create \n");
		printf("press 2 for display \n");
		scanf("%d",&choice);
		
		switch(choice)
		{
			case 1:printf("enter value :- \n");
		    scanf("%d",&val);
		    root=insert(root,num);
			break;
			
			case 2://display();
			break;
			
			default:printf("wrong choice\n");
		}
	}while(choice != 14);
	return 0;
}

struct node *insert(node*root,int num)
{
	if(start==NULL)
	{
		start=(struct node*)malloc(sizeof(struct node));
		start->data=num;
		start->left=NULL;
		count++;
	}
	else 
	{
		if(count%2==0)
		{
		root->left=insert(root->left,num);
	    }
	    else
	    {
	   	root->right=insert(root->right,num);
		}		
	}
	return(root);
}

/*
void display()
{
	if(start==NULL)
	{
		printf("empty list \n");
	}
	else
	{
		q=start;
		for(q=start;q!=NULL;q=q->next)
		{
			printf("  %d\n",q->data);
		}
	}
}
*/
