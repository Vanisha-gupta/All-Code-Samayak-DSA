#include<stdio.h>
int main(){
	int n,a[20],i,elem;
	printf("enter the size of array :- ");
	scanf("%d",&n);
	printf("n :- %d",n);
	if(n>0 && n<=20)
	{
		for(i=0;i<n;i++)
		{
		  printf("enter the element in array :- ");
		  scanf("%d",&a[i]);
    	}
		printf("enter the element for searching :- ");
		scanf("%d",&elem);
		
		for(i=0;i<n;i++)
		{
			if(a[i]==elem)
			{
				printf("searched element is present at position :- %d",i+1);
				break;
			}
		}
	}
	//scanf("%d");
	getch();//use for holding screen if programm execute using exe file
	return 0;
}