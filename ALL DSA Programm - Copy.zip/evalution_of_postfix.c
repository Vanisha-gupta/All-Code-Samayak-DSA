#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *next;
}*top,*q,*t;

//void calc(char[],int);
//void pop();
void push();
void display();

int main(){
	int choice,i;
	char val[6];
	top=NULL;
	do
	{
		printf("press 1 for insertion \n");
        scanf("%d",&choice);
		 switch(choice)
		 {
		 	case 1:printf("enter value in link list :- ");
		 	scanf("%s",val);
		 	calc(val);
		 	break;
		 	case 2:display();
		 	break;
		 	default:printf("wrong choice\n");
		 }
	}while(choice!=11);
	return 0;
}

void push(char num[6])
{
	q=top;
	t=(struct node*)malloc(sizeof(struct node));
	strcpy(t->data,num);
	t->next=top;
	top=t;
}


void calc(char n[], int p)
{
	int x,y;
	x=pop();
	y=pop();
	
	switch(n)
		 {
		 	case "+":push(y+x);
		 	break;
		 	case "-":push(y-x);
		 	break;
		 	case "*":push(y*x);
		 	break;
		 	case "/":push(y/x);
		 	break;
		 	default:push(atoi(n));
		 }
}

void pop()
{
	if(top==NULL)
	printf("underflow");
	else
	{
		printf("pop item is :- %d\n",top->data);
		top=top->next;
	}
}

void display()
{
	if(top==NULL)
			printf("underflow \n");
		else
	for(q=top;q!= NULL;q=q->next)
		printf(" %s\n",q->data);
}
		