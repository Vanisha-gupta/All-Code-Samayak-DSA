void sum(int a,int b)
{
	printf("the sum of the two number is :- %d",a+b);
}

void mult(int a,int b)
{
	printf("the multiplication of the two number is :- %d",a*b);
}

void minus(int a,int b)
{
	printf("the minus of the two number is :- %d",a-b);
}

void div(int a,int b)
{
	printf("the division of the two number is :- %d",a/b);
}

void pow(int a,int b)
{
	printf("the power of number a ^ b is :- %d",a**b);
}