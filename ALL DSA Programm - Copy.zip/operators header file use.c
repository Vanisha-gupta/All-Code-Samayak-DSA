#include<stdio.h>
#include"my header file.h"
int main(){
	sum(2,3);
	mult(2,3);
	minus(6,2);
	div(10,2);
	pow1(2,3);
	return 0;	
	
}