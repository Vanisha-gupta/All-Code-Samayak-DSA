#include<stdio.h>
int main()
{
	int i,j,n,m,val,count=0;
	int a[10][10];
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("enter element :- ");
			scanf("%d",&a[i][j]);
			if(a[i][j]==0)
			{
				count++;
			}
		}
	}
	
	if(count>=(m*n)/2)
	{
		printf("sparse matrix \n");
	}
	else
	{
		printf("not a sparse matrix \n");		
	}
	return 0;	
}