#include<stdio.h>  
#include<stdlib.h>  
#include<stdbool.h>   
void postorder(struct node *root);
void preorder(struct node *root);
void inorder(struct node *root);
//Represent a node of binary tree  
struct node{  
    int data;  
    struct node *left;  
    struct node *right;  
};   
struct node *root = NULL;  
struct node* createNode(int data){  

struct node *newNode = (struct node *)malloc(sizeof(struct node));  
    newNode->data = data;  
    newNode->left = NULL;  
    newNode->right = NULL;  
    return newNode;  
}  
//Represent a queue  
struct queue
{
	struct node *data;
	struct queue *next;
}*start,*front,*rear; 
   
/*struct queue* createQueue()  
{  
    struct queue* newQueue = (struct queue*) malloc(sizeof( struct queue ));  
    newQueue->front = -1;  
    newQueue->rear = 0;  
    newQueue->size = 0;  
    newQueue->arr = (struct node*) malloc(100 * sizeof( struct node ));  
    return newQueue;  
} */ 
   
//Adds a node to queue  
void enqueue(struct queue* queue, struct node *temp){  
    queue->arr[queue.rear++] = temp;  
    queue->size++;  
}  
     
struct node dequeue(struct queue queue){  
    queue.size--;  
    return queue.arr[++queue.front];  
}   
void insertNode(int data) {  
    //Create a new node  
    struct node *newNode = createNode(data);  
    //Check whether tree is empty  
    if(root == NULL){  
        root = newNode;  
        return;  
    }  
    else {  
        struct queue* queue = createQueue();  
        enqueue(queue, root);  
          
        while(true) {  
            struct node *node = dequeue(queue);  
            if(node->left != NULL && node->right != NULL) {  
                enqueue(queue, node->left);  
                enqueue(queue, node->right);  
            }  
            else {  
                if(node->left == NULL) {  
                    node->left = newNode;  
                    enqueue(queue, node->left);  
                }  
                else {  
                    node->right = newNode;  
                    enqueue(queue, node->right);  
                }  
                break;  
            }  
        }  
    }  
}  
   
int main(){  
int choice,val;
	do
		{
		printf("press 1 for insertion \n");
		printf("press 2 for display \n");
		printf("press 3 for delete \n");
		printf("press 4 for Exit \n");
		
		scanf("%d",&choice);
		 switch(choice)
		 {
		 	case 1:printf("enter value in binary tree :- ");
		 	scanf("%d",&val);
		 	insertNode(val);
		 	break;
		 	
		 	case 2:inorder(root);
		 	break;
		 	
		 	
		 	default:printf("wrong choice\n");
		 }
	}while(choice<4);
	return 0;
}

void preorder(struct node *root)
{
	if(root != NULL)
	{
		printf("%d",tree->data);
		preorder(root->left);
		preorder(root->right);
	}
}

void inorder(struct node *root)
{
	if(root != NULL)
	{
		inorder(root->left);
		printf("%d",root->data);
		inorder(root->right);
	}
}
void postorder(struct node *root)
{
	if(root != NULL)
	{
		postorde(root->left);
		postorder(root->right);
		printf("%d",tree->data);
	}
}