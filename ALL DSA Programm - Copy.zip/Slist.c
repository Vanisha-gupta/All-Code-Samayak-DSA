#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *next;
}*start,*q,*t;

void create (int num);
void display();
void count();
void at_start(int num);
void at_pos(int num);
void del_at_end();
void search(int num);
void reverse(int);// insert at front  
void reversing();// reverse a presented linklist error
void sort();

int main(){
	int choice,i,val;
	start=NULL;
	do
	{
		printf("press 1 for insertion \n");
		printf("press 2 for display \n");
		printf("press 3 for counting \n");
		printf("press 4 for insert at start \n");
		printf("press 5 for insert at position \n");
		printf("press 6 for deletion \n");
		printf("press 7 for searching \n");
		printf("press 8 for reversed list \n");
		printf("press 9 for reversing list \n");
		printf("press 10 for sorted list \n");
		printf("press 11 for Exit \n");
		scanf("%d",&choice);
		 switch(choice)
		 {
		 	case 1:printf("enter value in link list :- ");
		 	scanf("%d",&val);
		 	create(val);
		 	break;
		 	
		 	case 2:display();
		 	break;
		 	
		 	case 3:count();
		 	break;
		 	
		 	case 4:printf("enter value in link list :- ");
		 	scanf("%d",&val);
		 	at_start(val);
		 	break;
		 	
		 	case 5:printf("enter value in link list :- ");
		 	scanf("%d",&val);
		 	at_pos(val);
		 	break;
		 	
		 	case 6:del_at_end();
		 	break;
		 	
		 	case 7:printf("enter value for searching :- ");
		 	scanf("%d",&val);
			search(val);
			 break;
			 
			 case 8:printf("enter value for reversing list :-");
		 	scanf("%d",&val);
			reverse(val);
			break;
			
			case 9:reversing();
			break;
			
			case 10:sort();
			break;
		 	
		 	default:printf("wrong choice\n");
		 }
	}while(choice!=11);
	return 0;
}

void create (int num)
{
	if(start==NULL)
	{ 
		start=(struct node*)malloc(sizeof(struct node));
		start ->data=num;
		start ->next=NULL;
	}
	else
	{
			q=start;
			while(q->next != NULL)
			{
				q=q->next;
			}
			t=(struct node*)malloc(sizeof(struct node));
			t->data =num;
			t->next=NULL;
			q->next=t;
	}
}
void display()
{
	if(start==NULL)
			printf("empty list\n");
		else
	for(q=start;q!= NULL;q=q->next)
		printf(" %d\n",q->data);
}

void count()
{
	int n=0;
	for(q=start;q!=NULL;q=q->next)
	{
		n++;
	}
	printf("\n number of presented nodes are :- %d\n",n);
}

void at_start(int num)
{
	q=start;
	t=(struct node*)malloc(sizeof(struct node));
	t->data=num;
	t->next=start;
	start=t;	
}
void at_pos(int num)
{
	int pos,i;
	q=start;
	printf("enter the position where to insert :- ");
	scanf("%d",&pos);
	
	for(i=1;i<pos-1;i++)
	{
		q=q->next;
	}
	if(q==NULL)
	{
		printf(" empty link list ");
	}
	t=(struct node*)malloc(sizeof(struct node));
	t->data=num;
	t->next=q->next;
	q->next=t;
	printf("element inserted \n");	
}
void del_at_end()
{
	q=start;
	struct node *temp;
	if(q==NULL)
	{
		printf("nothing can be deleted\n");
	}
	else{
	for(q=start;q!=NULL;q=q->next)
	{
		if(q->next->next==NULL)
		{
		temp=q;
		break;
		}
	}
	temp->next=NULL;
}
}
	
void search(int num)
{
	q=start;
	int c=0;
	for(q=start;q!=NULL;q=q->next)
	{
    	c++;
		if(q->data == num)
		{
			printf("value present at %d\n",c);
		}
	}
}

void reverse(int num){
	q=start;
	if(start==NULL)
	{
		q=(struct node*)malloc(sizeof(struct node));
		q->data=num;
		q->next=NULL;
		start=q;
	}
	else
	{
		t=(struct node*)malloc(sizeof(struct node));
		t->data=num;
		t->next=start;
		start=t;
		
	}
}

void reversing()
{
	struct node *current,*prev,*nextn;
	prev=NULL;
	current=nextn=start;
	while(nextn != NULL)
	{
		nextn=nextn->next;
		current->next=prev;
		prev=current;
		current=nextn;
	}
	start->next=prev;
}

void sort()
{ int temp;
    q=start;
    while(q!=NULL)
    {
    	t=q->next;
    	while(t!=NULL)
    	{
		   if(q->data>t->data)
    	  {
		   temp=q->data;
    	   q->data=t->data;
    	   t->data=temp;
		  }
		t=t->next;
		}
		q=q->next;
	}
}