#include<stdio.h>
void input(int arr[][10],int a,int b);
void output(int arr[][10],int a,int b);
void mult( );
int main(){
	int n,m,p,q;
	int arr1[100][100],arr2[100][100];
	printf("Enter the value of number of rows for 1st matrix :- \n");
	printf("Enter the value of number of columns for 1st matrix :- \n");
	scanf("%d%d",&n,&m);
	printf("Enter the value of number of rows for 2nd matrix :- \n");
	printf("Enter the value of number of columns for 2nd matrix :- \n");
	scanf("%d%d",&p,&q);
	if(m!=p)
	{
		printf("\n this value not able to perform multiplication \n");
	}
	
	else
	{
		printf("\n 1st matrix input\n");
		input(arr1,n,m);
		printf("\n 2nd matrix input\n");
		input(arr2,p,q);
		printf("\n output of 1st matrix \n");
		output(arr1,n,m);
		printf("\n output of 2nd matrix \n");
		output(arr2,p,q);
		printf("\n multiplication \n");
		mult(arr1,arr2,n,q);
    return 0;	
}
}

void input(int arr[][10],int a,int b){
	int i,j;
	for(i=0;i<a;i++)  
	{
		for(j=0;j<b;j++)
		{
			printf("enter the element in array :- \n");
			scanf("%d",&arr[i][j]);
		}
	}
}

void mult(int a[][10],int b[][10],int c,int d)
{
	int mul[c][d],i,j,k,sum;
	for(i=0;i<c;i++)
		{
			for(j=0;j<d;j++)
			{
				for(k=0;k<d;k++)
				{
					sum=sum+a[i][k]*b[k][j];
				}
			mul[i][j]=sum;	
			}
		}
		
		for(i=0;i<c;i++)  
  	    {
		  for(j=0;j<d;j++)
		  {
			printf("%d\n",mul[i][j]);
	      }
	      printf("\n");
	   }
}
void output(int arr[][10],int a,int b)
{
	int i,j;
	for(i=0;i<a;i++)  
	{
		for(j=0;j<b;j++)
		{
			printf("%d ",arr[i][j]);
		}
		printf("\n");
	}
}