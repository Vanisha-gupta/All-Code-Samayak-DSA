#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *next;
}*start,*q,*t;

void create (int num);
void display();
void count();
void sort();

int main(){
	int choice,i,val;
	start=NULL;
	do
	{
		printf("press 1 for insertion \n");
		printf("press 2 for display \n");
		printf("press 3 for counting \n");
		printf("press 4 for sorting \n");
		printf("press 5 for exit \n");
		scanf("%d",&choice);
		switch(choice)
		 {
		 	case 1:printf("enter value in link list :- ");
		 	scanf("%d",&val);
		 	create(val);
		 	break;
		 	
		 	case 2:display();
		 	break;
		 	
		 	case 3:count();
		 	break;
		 	
		 	case 4:sort();
		 	break;
		 	
		 	default:printf("wrong choice\n");
		 }
	}while(choice!=5);
}


void create(int num)
{
	if(start==NULL)
	{ 
		start=(struct node*)malloc(sizeof(struct node));
		start ->data=num;
		start ->next=start;
	}
	
	else
	{
			q=start;
			while(q->next != start)
			{
				q=q->next;
			}
			t=(struct node*)malloc(sizeof(struct node));
			t->data =num;
			t->next=NULL;
			q->next=t;
			t->next=start;
	}
}

void display()
{
		if(start==NULL)
		{
			printf("empty list \n");
		}
		else
		{
			struct node *temp;
			temp=start;
			do
			{
				printf(" %d\n",temp->data);
				temp=temp->next;
			}while(temp != start);
		}
}

void count()
{
	int n=0;
	struct node *temp;
	temp=start;
			do
			{
				n++;
				temp=temp->next;
			}while(temp != start);
	printf("\nnumber of presented nodes are :- %d\n",n);
}

void sort()
{ 
    int temp;
    q=start;
    while(q->next!=start)
    {
    	t=q->next;
    	while(t!=start)
    	{
		   if(q->data>t->data)
    	  {
		   temp=q->data;
    	   q->data=t->data;
    	   t->data=temp;
		  }
		t=t->next;
		}
		q=q->next;
	}
}