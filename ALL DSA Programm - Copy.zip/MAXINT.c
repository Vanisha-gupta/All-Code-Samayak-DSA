#include<limits.h>
int main()
{
	printf("%d",INT_MAX);
}