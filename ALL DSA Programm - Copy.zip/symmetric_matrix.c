#include<stdio.h>
int main()
{
	int a[3][3]={1,4,1,1,6,1,1,1,9};
	int t,i,j,arr[3][3];
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			arr[i][j]=a[j][i];
		}
	}
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			if(arr[i][j]!=a[i][j]) // ==
			{
				printf("not a symmetric\n"); // printf("symmetric\n");
				break; // means
			}
			break;
			/*
			else
			{
				printf("not a symmetric\n");
			}*/
		}
	}
	
	return 0;	
}
