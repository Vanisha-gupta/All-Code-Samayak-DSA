#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *prev;
	struct node *next;
}*start,*q,*t;

void create(int);
void display();

int main()
{
	start=NULL;
	int choice,val;
	
	do{
		
		printf("press 1 for create \n");
		printf("press 2 for display \n");
		printf("press 3 for node \n");
		printf("press 11 for exit \n");
		scanf("%d",&choice);
		
		switch(choice)
		{
			case 1:printf("enter value :- \n");
		    scanf("%d",&val);
			create(val);
			break;
			
			case 2:display();
			break;
			
			default:printf("wrong choice");
		}
	}while(choice != 11);
	return 0;
}

void create(int num)
{
	if(start==NULL)
	{
		start=(struct node*)malloc(sizeof(struct node));
		start->data=num;
		start->next=NULL;
		start->prev=NULL;
	}
	else
	{
		q=start;
		while(q->next!=NULL)
		{
			q=q->next;
		}
		t=(struct node*)malloc(sizeof(struct node));
		t->data =num;
		t->next=NULL;
		t->prev=q;
		q->next=t;
	}
}

void diplay()
{
	if(start==NULL)
	{
		printf("empty list \n");
	}
	else
	{
		q=start;
		while(q!=NULL)
		{
			q=q->next;
			printf("%d",q->data);
		}
	}
}