#include<stdio.h>
#include<stdlib.h>
#define max 5
int qu[max];
int front=-1,rear=-1,i;

void insert_front(int);
void del_front();
void insert_rear(int);
void del_rear();
void display();

int main()
{
	int choice,val;
		do
		{
		printf("press 1 for insertion from front \n");
		printf("press 2 for delete from front \n");
		printf("press 3 for insertion from rear \n");
		printf("press 4 for  delete from rear \n");
		printf("press 5 for display \n");
		printf("press 6 for Exit \n");
		
		scanf("%d",&choice);
		 switch(choice)
		 {
		 	case 1:printf("enter value in link list :- ");
		 	scanf("%d",&val);
		 	insert_front(val);
		 	break;
		 	
		 	case 2:del_front();
		 	break;
		 	
		 	case 3:printf("enter value in link list :- ");
		 	scanf("%d",&val);
		 	insert_rear(val);
		 	break;
		 	
		 	case 4:del_rear();
		 	break;
		 	
		 	
		 	case 5:display();
		 	break;
		 	
		 	default:printf("wrong choice\n");
		 }
	}while(choice<6);
	return 0;
}


void insert_front(int n){
	if(rear>=(max-1))
	{
		printf(" element can not be insert\n");
	}
	else if(front==-1)
	{	
		++front;
		++rear;
		qu[rear]=n;
	}
	else
	{
		for(i=rear;i>=0;i--)
		{
			qu[i+1]=qu[i];
		}
		qu[front]=n;
		rear++;
	}
}

void del_front(){
	int i,j;
	if(rear==-1)
	{
	   printf("underflow \n");
	}
	else
	{
		for(i=0;i<=rear;i++)
		{
			qu[i]=qu[i+1];
		}
		--rear;
	}
}

void insert_rear(int n){
	if(front==-1)
	{
		++front;
		++rear;
		qu[rear]=n;
	}
	else if(rear>=(max-1))
	{
		printf(" element can not be insert\n");
	}
	else
	{
		++rear;
		qu[rear]=n;	
	}
}

void del_rear(){
	if(rear==-1)
	{
		printf("underflow queue");
	}
	else
	{
		--rear;
	}
	
}

void display(){
	for(i=front;i<=rear;i++)
		{
			printf("element is :- %d\n",qu[i]);
		}
}

