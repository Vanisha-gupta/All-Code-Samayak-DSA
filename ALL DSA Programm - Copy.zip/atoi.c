#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
	int a[10]={1,2,3};
	a[1]=3;
	char b[20];
	//strcpy(a,"abcd");
	int val,num;
	val=atoi(a);
//	printf("%d\n",isdigit("12"));//only check single value like :-1,2,3,_ _ _ .
	strcpy(b,"123");
	num=atoi(b);
	printf("%d\n",num);
	printf("%d",val);
	return 0;
}