#include<stdio.h>
int main(){
	int a=20,b=20,c=20;
	if(a>b && a>c)
	{
		printf("a is largest :- %d",a);
	}
	else if(b>c)
	{
		printf("b is largest :- %d",b);
	}
	else
	{
		printf("c is largest :- %d",c);
	}
	return 0;
}
