#include<stdio.h>
int main()
{
	int arr[10],n,i=1;
	char order;
	printf("enter the number of elememt for input :- ");
	scanf("%d",&n);
	printf("enter order a or A for asscending or d or D for dessecending :- ");
	fflush(stdin); // use for flush buffer memory 
	scanf("%c",&order);
	return 0;

}