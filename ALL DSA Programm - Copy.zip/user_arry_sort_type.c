// here user give the array input in the same order as he decided
// aur badi digit i/p lene pe bhi naho chal raha like 9
#include<stdio.h>
int main()
{
	int a[10],n,i,j,k,temp;
	char order;
	printf("enter the number of elememt for input :- ");
	scanf("%d",&n);
	printf("enter order a or A for asscending or d or D for dessecending :- ");
	fflush(stdin); // use for flush buffer memory 
	scanf("%c",&order);
	if(order=='a' || order=='A' || order=='d'||order=='D')
	{
		for(k=0;k<n;k++)
		{
			printf("enter element :- ");
	    	scanf("%d",&a[k]);
	    	if(k>0) // problem
             	{
             		if((order=='a' || order=='A') && a[k]<a[k-1])
             		{
					temp=a[k];
             		a[k]=a[k-1];
             		a[k-1]=temp;
             	   }
             	   else if ((order=='d' || order=='d') && a[k]>a[k-1])
             	   {
             	   	temp=a[k];
             		a[k]=a[k-1];
             		a[k-1]=temp;
				  }
				}
		}
	}
	else
	{
		printf("ENTER VALID CHOICE ");
	}
	printf("\n array entry is \n");
	for(i=0;i<n;i++)
	{
		printf("array elemnet is :- %d\n",a[i]);
	}
}