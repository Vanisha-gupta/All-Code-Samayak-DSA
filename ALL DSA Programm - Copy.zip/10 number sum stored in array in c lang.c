#include<stdio.h>
int main(){
	int i,sum=0,avg;
	int arr[10];
	for(i=0;i<10;i++)
	{
		printf("ENTER THE ELEMENT IN ARRAY :- ");
		scanf("%d",&arr[i]);
	//	printf("hii");
		sum=sum+arr[i];
	}
	avg=sum/10;
	printf("AVERAGE OF ALL NUMBER IS :- %d",avg);
}