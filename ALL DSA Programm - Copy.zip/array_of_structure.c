#include<stdio.h>
struct student{
	int roll_no;
	char name[50];
	int marks[50];
	int per;
};
int main(){
	int n,m,i,j;
	printf("enter the number of student :- ");
	scanf("%d",&n);
	struct student st[20];
	printf("enter the number of subject :- ");
	scanf("%d",&m);
	for(i=0;i<n;i++)
	{
			printf("enter name :- ");
			scanf("%s",&st[i].name);
			printf("enter roll number :- ");
			scanf("%d",&st[i].roll_no);
			st[i].per=0;
		for(j=0;j<m;j++)
		{
			printf("enter the marks :- ");
			scanf("%d",&st[i].marks[j]);
			st[i].per+=st[i].marks[j];
		}
		st[i].per=(st[i].per/m);
 	}
 	
 	// swaping the data
 	
	 struct student s[20];
 	
 	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n-i-1;j++)
		{
			if(st[j].per<st[j+1].per)
			{
				s[i]=st[j];
				st[j]=st[j+1];
				st[j+1]=s[i];	
			}
		}
	}
	printf("\n");
	
	for(int i=0;i<n;i++)
	{
		printf("roll no :-  %d  ",st[i].roll_no);
		printf("name :- %s  ",st[i].name);
		printf("percentage :-  %d  ",st[i].per);
	    printf("\n");

	}
	return 0;
}