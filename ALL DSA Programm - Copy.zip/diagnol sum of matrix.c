#include<stdio.h>
int main(){
	int n,m,i,j,sum1=0,sum2=0;	
	printf("Enter the value of number of rows for matrix :- \n");
	printf("Enter the value of number of columns for matrix :- \n");
	scanf("%d%d",&n,&m);
	int arr[n][m];
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("enter the value of element :- \n");
			scanf("%d",&arr[i][j]);
		}
	}
	
	for(i=0;i<n;i++)
	{
		sum1=sum1+arr[i][i];
		/*for(j=0;j<m;j++)
		{
			if(i==j)
			{
				printf("hii\n");
				sum1=sum1+arr[i][j];
			}
		}*/
	}
	
	for(i=0;i<n;i++)
	{
	//	for(j=0;j<m;j++)
	//	{
			sum2=sum2+arr[i][m-i-1];
	//	}
	}
	printf("the value of sum1 %d\n",sum1);
	printf("the value of sum2 %d\n",sum2);

}
