#include<stdio.h>
int main()
{
	int a[10],n,i=1;
	char order;
	printf("enter the number of elememt for input :- ");
	scanf("%d",&n);
	printf("enter order a or A for asscending or d or D for dessecending :- ");
	fflush(stdin); // use for flush buffer memory 
	scanf("%c",&order);
	
	if(order=='a' || order=='A')
	{
		printf("enter element :- ");
		scanf("%d",&a[0]);
		while(i<n)
		{
			printf("enter element :- ");
	    	scanf("%d",&a[i]);
			if(a[i]>a[i-1])
			{
				i++;
		    }
		    else
		    {
		    	printf("enter large number ");
			}
		}
	}
	
	else if(order == 'd' || order =='D')
	{
		printf("enter element :- ");
		scanf("%d",&a[0]);
		while(i<n)
		{
			printf("enter element :- \n");
			scanf("%d",&a[i]);
			if(a[i]<a[i-1])
			{
				i++;
		    }
		    else
		    {
		    	printf("enter small number \n");
			}
		}
	}
	printf("\n aay entry is \n");
	for(i=0;i<n;i++)
	{
		printf("aay elemnet is :- %d\n",a[i]);
	}
	
	
	return 0;

}