#include<climits>
int main()
{
	printf("%d",INT_MAX);
}