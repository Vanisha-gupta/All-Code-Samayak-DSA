#include<stdio.h>
struct adjacent
{
	struct node *advertex; // data part type
	struct adjacent *nextedge; //
}
struct node
{
	int status =1; // for cunting ststus whether in queue or not 
	char data; // vertex name 
	struct node *nextnode; //below node
	struct adjacent *cedge; //connectededge
	
}