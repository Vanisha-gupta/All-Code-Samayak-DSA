#include<stdio.h>
void input(int arr[][10],int a,int b);

int main(){
	int n,m,p,q;
	printf("Enter the value of number of rows for 1st matrix :- \n");
	printf("Enter the value of number of columns for 1st matrix :- \n");
	scanf("%d%d",&n,&m);
	printf("Enter the value of number of rows for 2nd matrix :- \n");
	printf("Enter the value of number of columns for 2nd matrix :- \n");
	scanf("%d%d",&p,&q);

	int arr1[n][m],arr2[p][q],c[m][m],sum=0,i,j,k;
	
	if(m!=p)
	{
		printf("\n this value not able to perform multiplication \n");
	}
	
	{
		
	int i,j;
	printf("first matrix input \n ");
	for(i=0;i<n;i++)  
	{
		for(j=0;j<m;j++)
		{
			printf("enter the element in array :- ");
			scanf("%d",&arr1[i][j]);
		}
	}
	printf("second matrix input \n");
	for(i=0;i<p;i++)  
	{
		for(j=0;j<q;j++)
		{
			printf("enter the element in array :- ");
			scanf("%d",&arr2[i][j]);
		}
	}
		// MULTIPLICATION 
		for(i=0;i<m;i++)
		{
			for(j=0;j<m;j++)
			{
				for(k=0;k<m;k++)
				{
					sum=sum+arr1[i][k]*arr2[k][j];
				}
			c[i][j]=sum;	
			}
		}
		
		for(i=0;i<m;i++)  
  	    {
		  for(j=0;j<m;j++)
		  {
			printf("%d\n",c[i][j]);
	      }
	      printf("\n");
	   }
	}

    return 0;
	
}
