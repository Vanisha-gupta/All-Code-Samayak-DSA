#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *next;
}*start,*front,*rear;

void insert(int);
void del();
void display();

int main()
{
	int choice,val;
	start=NULL;
		do
		{
		printf("press 1 for insertion \n");
		printf("press 2 for display \n");
		printf("press 3 for delete \n");
		printf("press 4 for Exit \n");
		
		scanf("%d",&choice);
		 switch(choice)
		 {
		 	case 1:printf("enter value in link list :- ");
		 	scanf("%d",&val);
		 	insert(val);
		 	break;
		 	
		 	case 2:display();
		 	break;
		 	
		 	case 3:del();
		 	break;
		 	
		 	default:printf("wrong choice\n");
		 }
	}while(choice<4);
	return 0;
}

void insert(int num)
{
	if(start==NULL)
	{
		start=(struct node*)malloc(sizeof(struct node));
		start->data=num;
		start->next=NULL;
	}
	else
	{
			front=start;
			while(front->next != NULL)
			{
				front=front->next;
			}
		
		rear=(struct node*)malloc(sizeof(struct node));
		rear->data=num;
		rear->next=NULL;
		front->next=rear;
	}
}

void del()
{
	if(start==NULL)
	{
		printf("underflow queue");
	}
	else
	{
		start=start->next;
	}
}

void display()
{
	if(start==NULL)
			printf("empty list\n");
		else
	for(front=start;front!= NULL;front=front->next)
		printf(" %d\n",front->data);

}

