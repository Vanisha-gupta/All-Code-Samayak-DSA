#include<stdio.h>
int main()
{
	float a=10.3859363;
	printf("%0.2f",a);
	return 0;
}