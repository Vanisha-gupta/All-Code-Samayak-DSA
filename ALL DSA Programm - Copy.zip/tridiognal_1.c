#include<stdio.h>
int main()
{
	int n,m,i,j,count=0;
	printf("enter the value of row :- ");
	scanf("%d",&n);
	int a[10][10];
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("enter element :- \n");
			scanf("%d",&a[i][j]);
			if(i==j || i==j+1 || j==i+1)
			{
			  if(a[i][j]==0)
			  {
				count=1;
				printf("not a diagnol");
				break;
			  }
			}
			else if(a[i][j] != 0)
			{
				count=1;
				printf("not a diagnol matrix");
				break;
			}
		if(count==1)
		{
			break;
		}	
		else
		{
			printf("diagnol matrix");
		}
		
		}
	}
	return 0;
}
