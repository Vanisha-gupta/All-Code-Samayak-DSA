#include<stdio.h>
int main(){
	while(printf("hii\n"));
	{
		printf("hello world");
		
		// print hii (infinite time)
		
	}
	/*
	while(printf(""));
	{
		printf("hello world");
	}
	
	only print hello world one time 
	
	*/
	return 0;
}