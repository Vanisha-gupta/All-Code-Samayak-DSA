#include<stdio.h>
void sort(int a[],int c);
int main()
{
	int n,arr[20],i,elem;
	char order;
	printf("enter the size of array :- \n");
	scanf("%d",&n);
	if(n>0 && n<=20)
	{
		for(i=0;i<n;i++)
		{
		  printf("enter the element in array :- \n");
		  scanf("%d",&arr[i]);
    	}
    	printf("enter the type for sortings\n");
    	printf("A or a for asscending and D or d for desscending :-\n");
    	scanf("%c",&order);
    	sort(arr,n);
    	
	}
	//scanf("%d");
	getch();//use for holding screen if programm execute using exe file
	return 0;

}

void sort(int a[20],int c)
{
	printf("\n welcome to function \n");
	printf("value of c %d\n",c);
	
	int temp,i,j;
	for(i=0;i<c;i++)
	{
		for(j=i+1;j<c;j++)
		{
			if(a[i]>a[j])
             {
             	temp=a[i];
             	a[i]=a[j];
             	a[j]=temp;
			 }
 		}
	} 
	for(i=0;i<c;i++)
	printf("\n%d",a[i]);
}