#include<stdio.h>
#define max 10
int queue[max];
int front=-1,rear=-1;
void push(int);
void pop();
void display();
int main()
{
	int num;
	printf("enter number to push in stack :- ");
	scanf("%d",&num);
	push(num);
	printf("enter number to push in stack :- ");
	scanf("%d",&num);
	push(num);
	printf("enter number to push in stack :- ");
	scanf("%d",&num);
	push(num);
	pop();
	display();
}

void push( int n)
{
	if(front<=rear && rear<(max-1))
	{
		++rear;
		queue[rear]=n;
	}
	else
	{
		printf(" element can not be insert\n");
	}
}

void pop()
{
	if(front<=rear &&front != -1)
	{
	   front++;
	}
	else
	{
		printf("element can not be pop \n");
	}
}

void display()
{
	int i;
	for(i=front;i<=rear;i++)
		{
			printf("element is :- %d\n",queue[i]);
		}
}