#include<stdio.h>
int gcd(int a,int b)
{
	if(a<b)
	{
		gcd(b,a);
	}
	else if(a>=b && a%b==0)
	{
		return b;
	}
	else
	{
	 return	gcd(b,(a%b));
	}
}
int main()
{
	int n,m;
	printf("enter two number :- ");
	scanf("%d%d",&n,&m);
	printf("%d",gcd(n,m));
	return 0;
}