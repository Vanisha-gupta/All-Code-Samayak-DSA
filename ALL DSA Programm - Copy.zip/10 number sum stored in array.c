#include<iostream>
int main(){
	int i,sum=0,avg;
	int arr[10];
	for(i=0;i<10;i++)
	{
		cout<<"ENTER THE ELEMENT IN ARRAY :- ";
		cin>>arr[i];
	//	printf("hii");
		sum=sum+arr[i];
	}
	avg=sum/10;
	cout<<"AVERAGE OF ALL NUMBER IS :- "<<avg;
}