#include<stdio.h>
int main(){
	int a=9,b=90,max;
	float c=90.199;
	max=a>b?(a>c?a:c):(b>c?b:c);
	printf("max value is :- %f",max);
	return 0;
}