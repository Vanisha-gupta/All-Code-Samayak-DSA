#include<stdio.h>
int fib(int m)
{
	int fibo=1;
	if(m==0)
	return 0;
	else if(m==1)
	{
		return 1;
	}
	else
	{
		fibo=fib(m-1) + fib(m-2);
	}
}
int main()
{
	int n,i;
	printf("enter number of terms :- ");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("%d   ",fib(i));
	}
	return 0;
}