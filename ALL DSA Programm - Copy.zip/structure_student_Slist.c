#include<stdio.h>
#include<stdlib.h>
struct student{
	int roll_no;
	char name[50];
};

struct node
{
	struct student data;
	struct node *next;
}*start,*q,*t;
void create (char m[],int x);
void display();

int main(){
	int choice,i,val,b;
	char a[50];
	start=NULL;
	do
	{
		printf("press 1 for insertion \n");
		printf("press 2 for display \n");
		printf("press 11 for Exit \n");
		scanf("%d",&choice);
		 switch(choice)
		 {
		 	case 1:	printf("enter the name of student :- \n");
					scanf("%s",a);
					//printf("%s",a);
					printf("enter the roll number  :- ");
					scanf("%d",&b);
					create (a,b);
		 			break;
		 	
		 	case 2:display();
		 	break;
		 		
		 	default:printf("wrong choice\n");
		 }
	}while(choice!=11);
	return 0;
}

void create (char m[],int n)
{
	int i,j;
	struct student st;
	strcpy(st.name,m);
	st.roll_no=n;
 	if(start==NULL)
	{ 
		start=(struct node*)malloc(sizeof(struct node));
		start -> data =st;
		start -> next=NULL;
		printf("%s",(start -> data).name);
	}
}
void display()
{
	if(start==NULL)
			printf("empty list\n");
		else
	for(q=start;q!= NULL;q=q->next)
		printf(" %d\n",q->data);
}