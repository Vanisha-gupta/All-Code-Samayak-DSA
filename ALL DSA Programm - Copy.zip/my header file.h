#include<stdio.h>
#include<math.h>

//HOW TO USE POWER FUNCTION FROM MATHS HEADER FILE ?

void sum(int a,int b)
{
	printf("the sum of the two number is :- %d\n",a+b);
}

void mult(int a,int b)
{
	printf("the multiplication of the two number is :- %d\n",a*b);
}

void minus(int a,int b)
{
	printf("the minus of the two number is :- %d\n",a-b);
}

void div(int a,int b)
{
	printf("the division of the two number is :- %d\n",a/b);
}

void pow1(int a,int b)
{
	printf("the power of number a ^ b is :- %d\n",a*b);
}