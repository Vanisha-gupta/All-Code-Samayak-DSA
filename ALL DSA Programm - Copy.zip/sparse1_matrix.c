#include<stdio.h>
int main()
{
	int i,j,n,m,val,count=0;
	int a[n][m];
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			printf("enter element :- \n");
			scanf("%d",&a[i][j]);
			if(a[i][j]==0)
			{
				count++;
			}
		}
	}
	
	if(count>=(m*n)/2)
	{
		printf("sparse matrix");
	}
	else
	{
		printf("not a sparse matrix");		
	}
	return 0;	
}