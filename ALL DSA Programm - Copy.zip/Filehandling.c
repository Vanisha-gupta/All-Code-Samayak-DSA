#include<stdio.h>
int main()
{
	FILE *f1,*f2;
	char c;
	printf("Data input\n\n");
//	f1=fopen("input.txt","w");
	//f1=fopen("input.txt","a");
	f1=fopen("input.txt","w+");
while((c=getchar())!='`') // read from consol 
{
putc(c,f1);	// write to the file
} // whole while use for write in a file 

rewind(f1); // cursor from front 

while((c=getc(f1))!=EOF) // read from file 
{
putchar(c);	//write to the consol
}  // read from file

fclose(f1);
	/*f2=fopen("input.txt","r");
	while((c=getc(f2))!=EOF)
{
putchar(c);	
}
	fclose(f2);*/
}