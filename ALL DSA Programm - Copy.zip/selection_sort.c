#include<stdio.h>
int main()
{
	int a[]={9,9,0,1};
	int  i,j,loc=0;
	for(i=0;i<4;i++)
	{
		int smal=a[i];
		for(j=i+1;j<4;j++)  // use for check minimum element after location i
		{
			if(smal>a[j])
			{	
			   smal=a[j];
			   loc=j;
			}
		}	
			// SORTING 
		   int t;
			t=a[i];
			a[i]=a[loc];
			a[loc]=t;
	}
	
	// PRINTING
	for(int i=0;i<4;i++)
	{          
		printf("array sorted elemented :- %d\n",a[i]);
	}

	return 0;
}