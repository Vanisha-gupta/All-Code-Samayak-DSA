#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *prev;
	struct node *next;
}*start,*q,*t;

void create(int);
void display(); // forward traverse
void count();
void reversetra(); // reverse traverse 
void sort();
void del();
void delstart();
void insert_at_start(int);
void insert_at_pos(int);
void insert_at(int,int);
void search(int);
void forward(int);
void backward(int);


int main()
{
	start=NULL;
	int choice,val,position;
	do{
		printf("press 1 for create \n");
		printf("press 2 for display \n");
		printf("press 3 for node count \n");
		printf("press 4 for reverse traverse \n");
		printf("press 5 for sorting \n");
		printf("press 6 for deletion \n");
		printf("press 7 for insert at start \n");
		printf("press 8 for insert at pos \n");
		printf("press 9 for deletion from start \n");
		printf("press 10 for deletion from position \n");
		printf("press 11 for searching \n");
		printf("press 12 for forward traversing from a point \n");
		printf("press 13 for backward traversing from a point \n");
		printf("press 14 for exit \n");
		scanf("%d",&choice);
		
		switch(choice)
		{
			case 1:printf("enter value :- \n");
		    scanf("%d",&val);
			create(val);
			break;
			
			case 2:display();
			break;
			
			case 3:count();
			break;
			
			case 4:reversetra();
			break;
			
			case 5:sort();
			break;
			
			case 6:del();
			break;
			
			case 7:printf("enter value :- \n");
		    scanf("%d",&val);
			insert_at_start(val);
			break;
			
			case 8:printf("enter value :- \n");
		    scanf("%d",&val);
		    printf("enter position :- \n");
		    scanf("%d",&position);
		    insert_at(val,position);
			break;
			
			case 9:delstart();
			break;
			
			case 10:printf("enter position :- \n");
		    scanf("%d",&position);
			insert_at_pos(position);
			break;
			
			case 11:printf("enter value :- \n");
		    scanf("%d",&val);
			search(val);
			break;
			
			case 12:printf("enter value :- \n");
		    scanf("%d",&val);
			forward(val);
			break;
			
			case 13:printf("enter value :- \n");
		    scanf("%d",&val);
			backward(val);
			break;
			
			default:printf("wrong choice");
		}
	}while(choice != 14);
	return 0;
}

void create(int num)
{
	if(start==NULL)
	{
		start=(struct node*)malloc(sizeof(struct node));
		start->data=num;
		start->next=NULL;
		start->prev=NULL;
	}
	else
	{
		q=start;
		while(q->next!=NULL)
		{
			q=q->next;
		}
		t=(struct node*)malloc(sizeof(struct node));
		t->data =num;
		t->next=NULL;
		t->prev=q;
		q->next=t;
	}
}

void display()
{
	if(start==NULL)
	{
		printf("empty list \n");
	}
	else
	{
		q=start;
		for(q=start;q!=NULL;q=q->next)
		{
			printf("  %d\n",q->data);
		}
	}
}

void count()
{
	int c=0;
	for(q=start;q!=NULL;q=q->next)
	{
		c++;
	}
	printf("number of node are :- %d\n",c);
}

void reversetra()
{
	if(start==NULL)
	{
		printf("empty list \n");
	}
	else
	{
		struct node* temp;
		q=start;
		for(q=start;q!=NULL;q=q->next)
		{
			temp=q;
		}
		printf("REVERSE TRAVERSE LIST IS \n");
		for(t=temp;t!=NULL;t=t->prev)
		{
		printf("  %d\n",t->data);
		}
	}
}
void sort()
{ int temp;
    q=start;
    while(q!=NULL)
    {
    	t=q->next;
    	while(t!=NULL)
    	{
		   if(q->data>t->data)
    	  {
		   temp=q->data;
    	   q->data=t->data;
    	   t->data=temp;
		  }
		t=t->next;
		}
		q=q->next;
	}
}

void del()
{
	struct node *temp;
	if(start==NULL)
	{
		printf("nothing can be deleted");
	}
	else{
	for(q=start;q!=NULL;q=q->next)
	{
		if(q->next->next==NULL)
		{
		temp=q;
		break;
		}
	}
	temp->next=NULL;
}
}

void insert_at_start(int num)
{
	q=start;
	if(start==NULL)
	{
		start=(struct node*)malloc(sizeof(struct node));
		start->data=num;
		start->next=NULL;
		start->prev=NULL;
	}
	else
	{
		t=(struct node*)malloc(sizeof(struct node));
		t->data=num;
		t->next=start;
		t->prev=NULL;
		start=t;
	}
}
void insert_at(int num,int pos)
{
	q=start;
	int i;

	for(i=1;i<pos-1;i++)
	{
		q=q->next;
		if(q==NULL)
	{
		printf(" Empty link list ");
	}
	}
	// if is not executed
	
	t=(struct node*)malloc(sizeof(struct node));
	t->data=num;
	t->next=q->next;
	t->prev=q;
	q->next=t;
	printf("element inserted \n");	
}
void delstart()
{
	q=start;
	if(q==NULL)
	{
		printf("nothing can be deleted ");
	}
	else
	{
		start->next->prev=NULL;
        start=start->next;
	}
}

void insert_at_pos(int pos)
{
	q=start;
	int i;
	if(start==NULL)
	{
		printf("nothing can be delete\n");
	}
	else
	{
		for(i=1;i<pos-1;i++)
		{
			q=q->next;
		}
		q->next=q->next->next;
		q->next->prev=q;
	}
}

void search(int num)
{
	q=start;
	int c=0;
	for(q=start;q!=NULL;q=q->next)
	{
    	c++;
		if(q->data == num)
		{
			printf("value present at %d\n",c);
		}
	}
}

void forward(int num)
{
		if(start==NULL)
	{
		printf("empty list \n");
	}
	else
	{
		q=start;
		while(q!=NULL)
		{
			if(q->data==num)
			{
				while(q!=NULL)
				{
					printf("  %d\n",q->data);
					q=q->next;
				}
			}
			if(q!=NULL)
			q=q->next;
		}
	}
}

void backward(int num)
{
		if(start==NULL)
	{
		printf("empty list \n");
	}
	else
	{
		q=start;
		while(q!=NULL)
		{
			if(q->data==num)
			{
				while(q!=NULL)
				{
					printf("  %d\n",q->data);
					q=q->prev;
				}
			}
			q=q->next;
		}
	}
}