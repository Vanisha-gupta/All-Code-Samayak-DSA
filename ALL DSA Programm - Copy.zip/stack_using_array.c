#include<stdio.h>
#define max 10

int stack[max];
int top=-1;

void push(int);
void pop();
void display();
void update(int,int);
void peak(int);

int main()
{
	int num;
	printf("enter number to push in stack :- ");
	scanf("%d",&num);
	push(num);
	printf("enter number to push in stack :- ");
	scanf("%d",&num);
	push(num);
	printf("enter number to push in stack :- ");
	scanf("%d",&num);
	push(num);
	pop();
	display();
	printf("\n after updation \n");
	update(100,0);
	display();
	peak(1);
	printf("enter number to push in stack :- ");
	scanf("%d",&num);
	push(num);
	display();
}

void push( int n)
{
	if(top==max-1)
	{
		printf(" stack is overflow ");
	}
	else
	{
		++top;
		stack[top]=n;
		printf(" element inserted\n");
	}
}

void pop()
{
	if(top==-1)
	{
		printf("stack is underflow ");
	}
	else
	{
		top--;
	}
}

void display()
{
	int i;
	for(i=top;i>=0;i--)
		{
			printf("element is :- %d\n",stack[i]);
		}
}

void update(int num,int pos)
{
	if(pos>=max || pos>top)
	{
		printf("data can not be inserted ");
	}
	else
	{
		stack[pos]=num;
	}
}
void peak(int pos)
{
	int i;
	if(pos>max || pos>top)
	{
		printf("data can not be peak ");
	}
	else
	{
	for(i=top;i>=0;i--)
		{
			if(pos==i)
			printf("\nelement is :- %d\n",stack[i]);
		}
	}
}